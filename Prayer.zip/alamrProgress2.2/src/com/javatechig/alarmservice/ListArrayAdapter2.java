package com.javatechig.alarmservice;


import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListArrayAdapter2 extends ArrayAdapter<String> {
	ListTwo ob= new ListTwo();
	SetDistrict ob1= new SetDistrict();
	private final Context context;
	private final String[] values;
	Typeface font;
	public ListArrayAdapter2(Context context, String[] values) {
		super(context, R.layout.adapter2, values);
		//font = Typeface.createFromAsset(context.getAssets(), FONT);
		this.context = context;
		this.values = values;
	}
    
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		 //Typeface font = Typeface.createFromAsset(getActivity().getAssets(),"SolaimanLipi-8-Jan-2011.ttf");
		View rowView = inflater.inflate(R.layout.adapter2, parent, false);
		TextView textView = (TextView) rowView.findViewById(R.id.label);
		
		ImageView imageView = (ImageView) rowView.findViewById(R.id.logo);
		textView.setText(values[position]);
 
		// Change icon based on name
		String s = values[position];
		 ob.setTime();
		 String d=ob1.getDis();
		 
 
		System.out.println(s);
 
		if (s.equals(ob.date)) {
			imageView.setImageResource(R.drawable.date);
		} else if (s.equals(""+ob.sunRise)) {
			imageView.setImageResource(R.drawable.sunrise);
		} else if (s.equals(""+ob.sunSet)) {
			imageView.setImageResource(R.drawable.sunset);
		} else if (s.equals(ob.Fazor)) {
			imageView.setImageResource(R.drawable.fazar);
		} else if (s.equals(ob.Zohor)) {
			imageView.setImageResource(R.drawable.zohor);
		}else if (s.equals(ob.Asar)) {
			imageView.setImageResource(R.drawable.asar);
		} else if (s.equals(ob.Magrib)) {
			imageView.setImageResource(R.drawable.magrib);
		} else if (s.equals(ob.Esha)) {
			imageView.setImageResource(R.drawable.esha);
		} else if (s.equals(ob.seheri)) {
			imageView.setImageResource(R.drawable.seheri);
		} else if (s.equals(d)) {
			imageView.setImageResource(R.drawable.seheri);
		}
		else  {
			imageView.setImageResource(R.drawable.foraz);
		}
		return rowView;
	}
}