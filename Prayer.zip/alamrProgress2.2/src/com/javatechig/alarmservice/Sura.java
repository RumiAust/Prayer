package com.javatechig.alarmservice;

import android.app.ActionBar;
import android.app.Dialog;
import android.app.ListActivity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Sura extends ListActivity{
	static final String[] MOBILE_OS = 
            new String[] { "Sura Fatiha", "Sura Ar Rahaman", "Sura Yasin", "Sura Fil",
		"Sura Quaries", "Sura Maun", "Sura Kausar", "Sura Kafirun",
		"Sura Nasor", "Sura Lahab", "Sura Eklash", "Sura Falak",
		"Sura Nas"};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ActionBar acBar= getActionBar();
		acBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0066FF")));
		setListAdapter(new ListArrayAdapter(this,MOBILE_OS) );
		//ListArrayAdapter(getActivity, MOBILE_OS, "SolaimanLipi-8-Jan-2011.ttf");

	}

	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {

		//get selected items
		String selectedValue = (String) getListAdapter().getItem(position);
		//Toast.makeText(this, selectedValue, Toast.LENGTH_LONG).show();
		if(selectedValue.equals("Sura Fatiha")){
			dialogBox("Sura Fatiha ","All details of Sura Fatiha");
		}
      if(selectedValue.equals("Sura Ar Rahaman")){
    	  dialogBox("Sura Ar Rahaman ","All details Sura Ar Rahaman");
		}
      if(selectedValue.equals("Sura Yasin")){
    	  dialogBox("Sura Yasin ","All details of Sura Yasin");
      }
      if(selectedValue.equals("Sura Fil")){
    	  dialogBox("Sura Fil ","All details of Sura Fil ");
      }if(selectedValue.equals("Sura Fatiha")){
			dialogBox("Special Dua ","All details of Special  Dua");
		}
    if(selectedValue.equals("Sura Quaries")){
  	  dialogBox("Sura Quaries ","All details of Sura Quaries");
		}
    if(selectedValue.equals("Sura Maun")){
  	  dialogBox("Sura Maun ","All details of Sura Maun");
    }
    if(selectedValue.equals("Sura Eklash")){
  	  dialogBox("Sura Eklash ","All details of Sura Eklash ");
    }if(selectedValue.equals("Sura Lahab")){
		dialogBox("Sura Lahab ","All details of Sura Lahab");
	}
  if(selectedValue.equals("Sura Kafirun")){
	  dialogBox("Sura Kafirun ","All details of Sura Kafirun");
	}
  if(selectedValue.equals("Sura Nasor")){
	  dialogBox("Sura Nasor ","All details of Sura Nasor");
  }
  if(selectedValue.equals("Sura Kausar")){
	  dialogBox("Sura Kausar ","All details of Sura Kausar ");
  }if(selectedValue.equals("Sura Falak")){
	  dialogBox("Sura Falak","All details of Sura Falak ");
  }if(selectedValue.equals("Sura Nas")){
	  dialogBox("Sura Nas","All details of Sura Nas");
  }
		

	}
	public void dialogBox(String title,String msg){
		final Dialog d = new Dialog(this);
	  	d.setContentView(R.layout.customdialogbox);
		d.setTitle(title);
		TextView txt=(TextView)d.findViewById(R.id.tv1);
		txt.setText(msg);
		 Button b =(Button)d.findViewById(R.id.dialogButtonOK);
		b.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				d.dismiss();
			}
			
		});
		
		d.show();
	}
}
