package com.javatechig.alarmservice;

import android.app.ActionBar;
import android.app.Dialog;
import android.app.ListActivity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class Namaz extends ListActivity{
	static final String[] MOBILE_OS = 
            new String[] { "Faraz", "Sunnot", "Nofol", "Jummah","Eid","Special Namaz's",};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ActionBar acBar= getActionBar();
		acBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0066FF")));

		setListAdapter(new ListArrayAdapter(this,MOBILE_OS) );
		//ListArrayAdapter(getActivity, MOBILE_OS, "SolaimanLipi-8-Jan-2011.ttf");

	}

	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {

		//get selected items
		String selectedValue = (String) getListAdapter().getItem(position);
		//Toast.makeText(this, selectedValue, Toast.LENGTH_LONG).show();
		if(selectedValue.equals("Faraz")){
			dialogBox("Faraz Namaz ","All details of faraz Namaz");
		}
		if(selectedValue.equals("Sunnot")){
			dialogBox("Sunnot Namaz ","All details of Sunnot Namaz");
		}
		if(selectedValue.equals("Nofol")){
			dialogBox("Nofol Namaz ","All details of NoFol Namaz");
		}
		if(selectedValue.equals("Jummah")){
			dialogBox("Jumma Namaz ","All details of Jummar Namaz");
		}
		if(selectedValue.equals("Eid")){
			dialogBox("Eid Namaz ","All details of Eid-ul-Fitar Eid-Ul-Azha-namaz Namaz");
		}
		if(selectedValue.equals("Special Namaz's")){
			dialogBox("Special Namaz ","All details of Special Namaz Namaz");
		}
		

	}
	public void dialogBox(String title,String msg){
		final Dialog d = new Dialog(this);
	  	d.setContentView(R.layout.customdialogbox);
		d.setTitle(title);
		TextView txt=(TextView)d.findViewById(R.id.tv1);
		txt.setText(msg);
		 Button b =(Button)d.findViewById(R.id.dialogButtonOK);
		b.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				d.dismiss();
			}
			
		});
		
		d.show();
	}
}
