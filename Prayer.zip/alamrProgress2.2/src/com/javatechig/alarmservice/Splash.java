package com.javatechig.alarmservice;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;

public class Splash extends Activity{
	@Override
	protected void onCreate(Bundle rumi) {
		// TODO Auto-generated method stub
		super.onCreate(rumi);
		setContentView(R.layout.splash);
		Thread t = new Thread(){
			public void run(){
				try{
					sleep(2000);
				}catch(InterruptedException e){
					e.printStackTrace();
				}finally{
					Intent go = new Intent("com.javatechig.alarmservice.MainActivity");
					startActivity(go);
				}
			}
			
		};
		t.start();
		
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		finish();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		// TODO Auto-generated method stub
		super.onConfigurationChanged(newConfig);
	}
	


}
