package com.javatechig.alarmservice;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
public class NfTest extends Activity  {
	TextView tvt;
	Typeface font;
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar acBar= getActionBar();
		//acBar.setBackgroundDrawable(new ColorDrawable(0x0066FF));
		acBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0066FF")));
        setContentView(R.layout.receiver);
        tvt=(TextView)findViewById(R.id.recvertxt);
        font = Typeface.createFromAsset(getAssets(),"SolaimanLipi-8-Jan-2011.ttf");
        Intent i=getIntent();//eta tabhost e kaj kore nah crush kore
        String x=i.getExtras().getString("id1");
        tvt.setTypeface(font);
        tvt.setText(x);
       // Toast.makeText(getApplicationContext(), ""+x, Toast.LENGTH_LONG).show();
	}

}
