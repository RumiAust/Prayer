package com.javatechig.alarmservice;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

public class ListTwo extends ListActivity {
	SetDistrict dist = new SetDistrict();
	String sunRise="No Data Availabe",sunSet="No Data Availabe",
			Fazor="No Data Availabe",Zohor="No Data Availabe",
			Asar="No Data Availabe",Magrib="No Data Availabe",
			Esha="No Data Availabe",seheri="No Data Available";
	SimpleDateFormat mm,sdf;
	SimpleDateFormat mi;
	 Calendar c ;
	double month;
	double day;
	String date;
	String district="Dhaka";
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		district=dist.getDis();
		setTime();	
		String[] MOBILE_OS = 
	            new String[] { date, sunRise, sunSet,Fazor,Zohor,Asar, Magrib,Esha,seheri};


		setListAdapter(new ListArrayAdapter2(this,MOBILE_OS) );
		//ListArrayAdapter(getActivity, MOBILE_OS, "SolaimanLipi-8-Jan-2011.ttf");

	}

	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {

		//get selected items
		String selectedValue = (String) getListAdapter().getItem(position);
		//Toast.makeText(this, selectedValue, Toast.LENGTH_LONG).show();

	}
	public void initialization(String sunR,String sunS,String faz,String zoh,String asa,String mag,String es,String seh){
		   sunRise=sunR;
		   sunSet=sunS;
		   Fazor=faz;
		   Zohor=zoh;
		   Asar=asa;
		   Magrib=mag;
		   Esha=es;
		   seheri=seh;	   
		   
	   }
	 public void setTime(){
		    c = Calendar.getInstance();
	       mm = new SimpleDateFormat("MM");
	       mi = new SimpleDateFormat("dd");
	       sdf = new SimpleDateFormat("MM-dd-yyyy");
		   date="Today-> "+sdf.format(c.getTime());
	      String strMonth = mm.format(c.getTime());
	      String strMin = mi.format(c.getTime());
	      try{
	      double y=Double.parseDouble(strMonth);
	      double z=Double.parseDouble(strMin);
	       month=y;
	       day=z;
	       if(month==1){
	    	   January();
	       }else if(month==2){
	    	   February();
	       }else if(month==3){
	    	   March();
	       }else if(month==4){
	    	   April();
	       }else if(month==5){
	    	   May();
	       }else if(month==6){
	    	   June();
	       }else if(month==7){
	    	   July();
	       }else if(month==8){
	    	   August();
	       }else if(month==9){
	    	   September();
	       }else if(month==10){
	    	   October();
	       }else if(month==11){
	    	   November();
	       }else if(month==12){
	    	   December();
	       }

	      }catch(Exception e){

	      }
		   
	   }
	  public void August(){
		   if(day==15){
	     	   initialization("Sunrise-> 5:33 Am","Sunset-> 6:32 Pm","Fazor-> 4:15 Am",
	     			   "Zohor-> 12:06 Pm","Asar-> 4:38 Pm","Magrib-> 6:35 Pm","Esha-> 7:53 Pm","Seheri-> 4:11 Am");
	        }
		   if(day==16){
	     	   initialization("Sunrise-> 5:33 Am","Sunset-> 6:32 Pm","Fazor-> 4:15 Am",
	     			   "Zohor-> 12:06 Pm","Asar-> 4:38 Pm","Magrib-> 6:35 Pm","Esha-> 7:53 Pm","Seheri-> 4:11 Am");
	        }
		   if(day==17){
	     	   initialization("Sunrise-> 5:33 Am","Sunset-> 6:32 Pm","Fazor-> 4:15 Am",
	     			   "Zohor-> 12:06 Pm","Asar-> 4:38 Pm","Magrib-> 6:35 Pm","Esha-> 7:53 Pm","Seheri-> 4:11 Am");
	        }
	        if(day==18){
	      	   initialization("Sunrise-> 5:34 Am","Sunset-> 6:30 Pm","Fazor-> 4:17 Am",
	      			   "Zohor-> 12:05 Pm","Asar-> 4:37 Pm","Magrib-> 6:33 Pm","Esha-> 7:50 Pm","Seheri-> 4:12 Am");
	         }
	        if(day==19){
	        	  initialization("Sunrise-> 5:34 Am","Sunset-> 6:30 Pm","Fazor-> 4:17 Am",
	        			  "Zohor-> 12:05 Pm","Asar-> 4:37 Pm","Magrib-> 6:33 Pm","Esha-> 7:50 Pm","Seheri-> 4:12 Am");       	 
	         }
	        if(day==20){
	        	  initialization("Sunrise-> 5:34 Am","Sunset-> 6:30 Pm","Fazor-> 4:17 Am",
	        			  "Zohor-> 12:05 Pm","Asar-> 4:37 Pm","Magrib-> 6:33 Pm","Esha-> 7:50 Pm","Seheri-> 4:12 Am");	      	
		        }
		    if(day==21){
		      	   initialization("Sunrise-> 5:35 Am","Sunset-> 6:27 Pm","Fazor-> 4:18 Am",
		      			   "Zohor-> 12:05 Pm","Asar-> 4:35 Pm","Magrib-> 6:30 Pm","Esha-> 7:47 Pm","Seheri-> 4:12 Am");		       	 
		         }
		    if(day==22){
		      	   initialization("Sunrise-> 5:35 Am","Sunset-> 6:27 Pm","Fazor-> 4:18 Am",
		      			   "Zohor-> 12:05 Pm","Asar-> 4:35 Pm","Magrib-> 6:30 Pm","Esha-> 7:47 Pm","Seheri-> 4:12 Am");		       	
		         }
		    if(day==23){
		      	   initialization("Sunrise-> 5:35 Am","Sunset-> 6:27 Pm","Fazor-> 4:18 Am",
		      			   "Zohor-> 12:05 Pm","Asar-> 4:35 Pm","Magrib-> 6:30 Pm","Esha-> 7:47 Pm","Seheri-> 4:12 Am");		    
		        }
		      if(day==24){
		      	   initialization("Sunrise-> 5:36 Am","Sunset-> 6:25 Pm","Fazor-> 4:20 Am",
		      			   "Zohor-> 12:04 Pm","Asar-> 4:34 Pm","Magrib-> 6:28 Pm","Esha-> 7:44 Pm","Seheri-> 4:14 Am");		       
		         }
		      if(day==25){
		    	  initialization("Sunrise-> 5:36 Am","Sunset-> 6:25 Pm","Fazor-> 4:20 Am",
		    			  "Zohor-> 12:04 Pm","Asar-> 4:34 Pm","Magrib-> 6:28 Pm","Esha-> 7:44 Pm","Seheri-> 4:14 Am");		       	 
		         }
		      if(day==26){
		    	  initialization("Sunrise-> 5:36 Am","Sunset-> 6:25 Pm","Fazor-> 4:20 Am",
		    			  "Zohor-> 12:04 Pm","Asar-> 4:34 Pm","Magrib-> 6:28 Pm","Esha-> 7:44 Pm","Seheri-> 4:14 Am");			      	
			        }
			 if(day==27){
			      	   initialization("Sunrise-> 5:37 Am","Sunset-> 6:22 Pm","Fazor-> 4:22 Am",
			      			   "Zohor-> 12:03 Pm","Asar-> 4:32 Pm","Magrib-> 6:25 Pm","Esha-> 7:41 Pm","Seheri-> 4:16 Am");			       	 
			         }
			 if(day==28){
				 initialization("Sunrise-> 5:37 Am","Sunset-> 6:22 Pm","Fazor-> 4:22 Am",
						 "Zohor-> 12:03 Pm","Asar-> 4:32 Pm","Magrib-> 6:25 Pm","Esha-> 7:41 Pm","Seheri-> 4:16 Am");			       
			         }
			 if(day==29){
				 initialization("Sunrise-> 5:37 Am","Sunset-> 6:22 Pm","Fazor-> 4:22 Am",
						 "Zohor-> 12:03 Pm","Asar-> 4:32 Pm","Magrib-> 6:25 Pm","Esha-> 7:41 Pm","Seheri-> 4:16 Am");		      	
		        }
			 if(day==30){
		     	   initialization("Sunrise-> 5:39 Am","Sunset-> 6:19 Pm","Fazor-> 4:23 Am",
		     			   "Zohor-> 12:02 Pm","Asar-> 4:30 Pm","Magrib-> 6:22 Pm","Esha-> 7:37 Pm","Seheri-> 4:17 Am");		      	
		        }
			 if(day==31){
				  initialization("Sunrise-> 5:39 Am","Sunset-> 6:19 Pm","Fazor-> 4:23 Am",
						  "Zohor-> 12:02 Pm","Asar-> 4:30 Pm","Magrib-> 6:22 Pm","Esha-> 7:37 Pm","Seheri-> 4:17 Am");	      	
		        }
	   }
	public void January(){
		  
	  }
    public void February(){
		  
	  }
    public void March(){
    	 
	  }
    public void April(){
	  
     }
    public void May(){
	  
    }
    public void June(){
	  
    } 
    public void July(){
	  
    }
    public void September(){

		   if(day==1){
	     	   initialization("5:33 Am","6:32 Pm","4:15 Am","12:06 Pm","4:38 Pm","6:35 Pm","7:53 Pm","4:11 Am");
	        }
		   if(day==2){
	     	   initialization("5:33 Am","6:32 Pm","4:15 Am","12:06 Pm","4:38 Pm","6:35 Pm","7:53 Pm","4:11 Am");
	        }
	        if(day==3){
	      	   initialization("5:34 Am","6:30 Pm","4:17 Am","12:05 Pm","4:37 Pm","6:33 Pm","7:50 Pm","4:12 Am");
	         }
	        if(day==4){
	        	  initialization("5:34 Am","6:30 Pm","4:17 Am","12:05 Pm","4:37 Pm","6:33 Pm","7:50 Pm","4:12 Am");       	 
	         }
	        if(day==5){
	        	  initialization("5:34 Am","6:30 Pm","4:17 Am","12:05 Pm","4:37 Pm","6:33 Pm","7:50 Pm","4:12 Am");	      	
		        }
		    if(day==6){
		      	   initialization("5:35 Am","6:27 Pm","4:18 Am","12:05 Pm","4:35 Pm","6:30 Pm","7:47 Pm","4:12 Am");		       	 
		         }
		    if(day==7){
		      	   initialization("5:35 Am","6:27 Pm","4:18 Am","12:05 Pm","4:35 Pm","6:30 Pm","7:47 Pm","4:12 Am");		       	
		         }
		    if(day==8){
		      	   initialization("5:35 Am","6:27 Pm","4:18 Am","12:05 Pm","4:35 Pm","6:30 Pm","7:47 Pm","4:12 Am");		    
		        }
		      if(day==9){
		      	   initialization("5:36 Am","6:25 Pm","4:20 Am","12:04 Pm","4:34 Pm","6:28 Pm","7:44 Pm","4:14 Am");		       
		         }
		      if(day==10){
		    	  initialization("5:36 Am","6:25 Pm","4:20 Am","12:04 Pm","4:34 Pm","6:28 Pm","7:44 Pm","4:14 Am");		       	 
		         }
		      if(day==11){
		    	  initialization("5:36 Am","6:25 Pm","4:20 Am","12:04 Pm","4:34 Pm","6:28 Pm","7:44 Pm","4:14 Am");			      	
			        }
			 if(day==12){
			      	   initialization("5:37 Am","6:22 Pm","4:22 Am","12:03 Pm","4:32 Pm","5:25 Pm","7:41 Pm","4:16 Am");			       	 
			         }
			 if(day==13){
				 initialization("5:37 Am","6:22 Pm","4:22 Am","12:03 Pm","4:32 Pm","5:25 Pm","7:41 Pm","4:16 Am");			       
			         }
			 if(day==14){
				 initialization("5:37 Am","6:22 Pm","4:22 Am","12:03 Pm","4:32 Pm","5:25 Pm","7:41 Pm","4:16 Am");		      	
		        }
			 if(day==15){
		     	   initialization("5:39 Am","6:19 Pm","4:23 Am","12:02 Pm","4:30 Pm","6:22 Pm","7:37 Pm","4:17 Am");		      	
		        }
			 if(day==16){
				  initialization("5:39 Am","6:19 Pm","4:23 Am","12:02 Pm","4:30 Pm","6:22 Pm","7:37 Pm","4:17 Am");	      	
		        }
		   if(day==17){
	     	   initialization("5:33 Am","6:32 Pm","4:15 Am","12:06 Pm","4:38 Pm","6:35 Pm","7:53 Pm","4:11 Am");
	        }
	        if(day==18){
	      	   initialization("5:34 Am","6:30 Pm","4:17 Am","12:05 Pm","4:37 Pm","6:33 Pm","7:50 Pm","4:12 Am");
	         }
	        if(day==19){
	        	  initialization("5:34 Am","6:30 Pm","4:17 Am","12:05 Pm","4:37 Pm","6:33 Pm","7:50 Pm","4:12 Am");       	 
	         }
	        if(day==20){
	        	  initialization("5:34 Am","6:30 Pm","4:17 Am","12:05 Pm","4:37 Pm","6:33 Pm","7:50 Pm","4:12 Am");	      	
		        }
		    if(day==21){
		      	   initialization("5:35 Am","6:27 Pm","4:18 Am","12:05 Pm","4:35 Pm","6:30 Pm","7:47 Pm","4:12 Am");		       	 
		         }
		    if(day==22){
		      	   initialization("5:35 Am","6:27 Pm","4:18 Am","12:05 Pm","4:35 Pm","6:30 Pm","7:47 Pm","4:12 Am");		       	
		         }
		    if(day==23){
		      	   initialization("5:35 Am","6:27 Pm","4:18 Am","12:05 Pm","4:35 Pm","6:30 Pm","7:47 Pm","4:12 Am");		    
		        }
		      if(day==24){
		      	   initialization("5:36 Am","6:25 Pm","4:20 Am","12:04 Pm","4:34 Pm","6:28 Pm","7:44 Pm","4:14 Am");		       
		         }
		      if(day==25){
		    	  initialization("5:36 Am","6:25 Pm","4:20 Am","12:04 Pm","4:34 Pm","6:28 Pm","7:44 Pm","4:14 Am");		       	 
		         }
		      if(day==26){
		    	  initialization("5:36 Am","6:25 Pm","4:20 Am","12:04 Pm","4:34 Pm","6:28 Pm","7:44 Pm","4:14 Am");			      	
			        }
			 if(day==27){
			      	   initialization("5:37 Am","6:22 Pm","4:22 Am","12:03 Pm","4:32 Pm","5:25 Pm","7:41 Pm","4:16 Am");			       	 
			         }
			 if(day==28){
				 initialization("5:37 Am","6:22 Pm","4:22 Am","12:03 Pm","4:32 Pm","5:25 Pm","7:41 Pm","4:16 Am");			       
			         }
			 if(day==29){
				 initialization("5:37 Am","6:22 Pm","4:22 Am","12:03 Pm","4:32 Pm","5:25 Pm","7:41 Pm","4:16 Am");		      	
		        }
			 if(day==30){
		     	   initialization("5:39 Am","6:19 Pm","4:23 Am","12:02 Pm","4:30 Pm","6:22 Pm","7:37 Pm","4:17 Am");		      	
		        }
	  
   } 
    public void October(){
	  
   }
    public void November(){
	  
    } 
    public void December(){
	  
    }
}
