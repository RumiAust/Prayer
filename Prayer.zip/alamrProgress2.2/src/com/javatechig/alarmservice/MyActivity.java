package com.javatechig.alarmservice;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MyActivity extends Activity {

    private PendingIntent pendingIntent,pendingIntent2;
    
    String h,m;  
    Button setTime;
    Intent alarmIntent;
	double time;
	double month;
	double min;
	Button bn;
	CheckBox F,Z,A,M,E;
	String fAzar="false",zOhor="false",aSar="false",mAgrib="false",eSha="false";
	public static final String DEFAULT ="N?A";
	TextView faz,zoh,asa,mag,esh;
	SharedPreferences  shf,shf2;
	String r1,r2,r3,r4,r5;
	TextView hdth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_activity);
        bn=(Button)findViewById(R.id.buttonclear);
        faz=(TextView)findViewById(R.id.textView1);
        zoh=(TextView)findViewById(R.id.textView2);
        asa=(TextView)findViewById(R.id.textView3);
        mag=(TextView)findViewById(R.id.textView4);
        esh=(TextView)findViewById(R.id.textView5);
        F=(CheckBox)findViewById(R.id.checkBox1);
        Z=(CheckBox)findViewById(R.id.checkBox2);
        A=(CheckBox)findViewById(R.id.checkBox3);
        M=(CheckBox)findViewById(R.id.checkBox4);
        E=(CheckBox)findViewById(R.id.checkBox5);
        hdth=(TextView)findViewById(R.id.hadith);
       Typeface font = Typeface.createFromAsset(getAssets(),"SolaimanLipi-8-Jan-2011.ttf");
        hdth.setTypeface(font);
       // hdth.setText("সকল কাজ মানুষের নিয়তের উপর নির্ভরশীল ।  গ্রন্থঃ সহীহ বুখারি (ইফা)	অধ্যায়ঃ ১/ ওহীর সূচনা	হাদিস নম্বরঃ 1");
        shf= getSharedPreferences("MyData",Context.MODE_PRIVATE);
        Calendar c = Calendar.getInstance();
        SimpleDateFormat hh = new SimpleDateFormat("HH");
        SimpleDateFormat mm = new SimpleDateFormat("MM");
        SimpleDateFormat mi = new SimpleDateFormat("mm");
        
        String strHour = hh.format(c.getTime());
        String strMonth = mm.format(c.getTime());
        String strMin = mi.format(c.getTime());
        try{
            double x=Double.parseDouble(strHour);
            double y=Double.parseDouble(strMonth);
            double z=Double.parseDouble(strMin);
             time=x;
             month=y;
             min=z;
            }catch(Exception e){
            	Toast.makeText(getBaseContext(),""+e, Toast.LENGTH_LONG).show();
            }
               showPreferences();
        /* Retrieve a PendingIntent that will perform a broadcast */

        findViewById(R.id.startAlarm).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start();
            }
        });

        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancel();
            }
        });
        

        
    }


    public void start() {
    	
    	getPreferences();
    	try{
    		if(time>=3 && time <13){
    			// Toast.makeText(getApplicationContext(), "zohor function !!"+time,Toast.LENGTH_LONG).show();
          	 Zohor();          
          }else if(time>=13 && time <=15 ){
          	if(time==15 && min>30){
              Magrib();
          	}else{
          		Asar();	
          	}
             }else if(time>=15  && time <17){
          	   //Toast.makeText(getApplicationContext(), "Magrib !!",Toast.LENGTH_LONG).show();
          	   Magrib();
             }else if(time>=17 && time <21){
            	 //Toast.makeText(getApplicationContext(), "Esha !!",Toast.LENGTH_LONG).show();
          	   Esha();
             }else{
            	 //Toast.makeText(getApplicationContext(), "Fazar function !!"+time,Toast.LENGTH_LONG).show();
          	   Fazar();
             }
    		
    	        showPreferences();
    	        
    	        Toast.makeText(this, "current hour:"+time, Toast.LENGTH_SHORT).show();
    	}catch(Exception e){
    		
    	}
    	
       
        
       
    }

    public void cancel() {
    	fAzar="false";zOhor="false";aSar="false";mAgrib="false";eSha="false";
    	SharedPreferences.Editor edit=shf.edit();
        edit.putString("fazar",fAzar);
        edit.putString("zohor",zOhor);
        edit.putString("asar",aSar);
        edit.putString("magrib",mAgrib);
        edit.putString("esha",eSha);
        edit.commit();
        showPreferences();
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
      // manager.cancel(pendingIntent);
       // Toast.makeText(this, "Null", Toast.LENGTH_SHORT).show();
       if (manager!= null) {
	            manager.cancel(pendingIntent);
	            Toast.makeText(this, "Hadith Getting According to prayer is Now cancelled!!", Toast.LENGTH_SHORT).show();
	        }else{
	        Toast.makeText(this, "Null Alarm", Toast.LENGTH_SHORT).show();
	        }
    }
  //--------------my functions---------------
    public void Fazar(){
    	int y=0;
       AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        
        alarmIntent = new Intent(MyActivity.this, AlarmReceiver.class);
        Bundle extras = new Bundle();
		extras.putString("id", "10");
		extras.putString("isChecked", "true");
		
		alarmIntent.putExtras(extras);
		pendingIntent = PendingIntent.getBroadcast(MyActivity.this,0,alarmIntent,PendingIntent.FLAG_UPDATE_CURRENT);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        //SimpleDateFormat sdf = new SimpleDateFormat("MM/DD/yyyy hh:mm:ss a");
        SimpleDateFormat sdf = new SimpleDateFormat("dd");
        String strDate = sdf.format(c.getTime());
        try{
        int x=Integer.parseInt(strDate);
         y=x;
        }catch(Exception e){
       	 Toast.makeText(this, " "+e, Toast.LENGTH_SHORT).show();
        }
        if((time ==0 || time==1 || time==2)){
        	/*
        	 * if(min<1){
        	 *  --time 24 insted 0
        	 *  --min<
        	 * }
        	 */
        	Toast.makeText(this, "NooooHH add day "+time, Toast.LENGTH_SHORT).show();
        	if(month==1 || month==2 || month==12){
                calendar.set(Calendar.HOUR_OF_DAY, 5);
                calendar.set(Calendar.MINUTE,0);
           		       }else if(month==5 || month==6){	
           		        calendar.set(Calendar.HOUR_OF_DAY, 3);
           		        calendar.set(Calendar.MINUTE,0);
         
           		       }else{	
           		        calendar.set(Calendar.HOUR_OF_DAY, 3);
           		        calendar.set(Calendar.MINUTE,45);
         
           		       }	
        }else{
        	Toast.makeText(this, "Need to add day "+time, Toast.LENGTH_SHORT).show();
    	
   	 if(month==1 || month==2 || month==12){
   		calendar.set(Calendar.DAY_OF_MONTH, y);	
        calendar.set(Calendar.HOUR_OF_DAY, 5);
        calendar.set(Calendar.MINUTE,0);
   		       }else if(month==5 || month==6){
   		    	calendar.set(Calendar.DAY_OF_MONTH, y);	
   		        calendar.set(Calendar.HOUR_OF_DAY, 3);
   		        calendar.set(Calendar.MINUTE,0);
 
   		       }else{
   		    	calendar.set(Calendar.DAY_OF_MONTH, y);	
   		        calendar.set(Calendar.HOUR_OF_DAY, 3);
   		        calendar.set(Calendar.MINUTE,45);
 
   		       }
        }
     manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
             1000 * 60 * 1, pendingIntent);
     
     
     Toast.makeText(this, "Alarm Set For Fazar "+y, Toast.LENGTH_SHORT).show();
   	
   }
    public void Zohor(){
    	//tv.setText("next Prayer is Zohor 1 Pm "+"\nHour:"+time+"\nMonth:"+month);
    	 AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
         
         alarmIntent = new Intent(MyActivity.this, AlarmReceiver.class);
        Bundle extras = new Bundle();
  		extras.putString("id", "20");	
  		alarmIntent.putExtras(extras);
        
        //alarmIntent.putExtra("getX", "2");
          PendingIntent pendingIntent2 = PendingIntent.getBroadcast(MyActivity.this, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
          Calendar calendar = Calendar.getInstance();
          calendar.setTimeInMillis(System.currentTimeMillis());
          calendar.set(Calendar.HOUR_OF_DAY, 13);
          calendar.set(Calendar.MINUTE,0);
          manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                  1000 * 60 * 1, pendingIntent2);
          Toast.makeText(this, " alarm set for Zohor !!!", Toast.LENGTH_SHORT).show();
    }
    public void Asar(){
        AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
         
        alarmIntent = new Intent(MyActivity.this, AlarmReceiver.class);
        Bundle extras = new Bundle();
  		extras.putString("id", "30");	
  		alarmIntent.putExtras(extras);
        
        //alarmIntent.putExtra("getX", "2");
          PendingIntent pendingIntent2 = PendingIntent.getBroadcast(MyActivity.this, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
          Calendar calendar = Calendar.getInstance();
          calendar.setTimeInMillis(System.currentTimeMillis());
    	if(month==10 || month==11 || month==12 || month==1){
    		calendar.set(Calendar.HOUR_OF_DAY, 15);
            calendar.set(Calendar.MINUTE,30);
    		//tv.setText("next Prayer is Asar 3:30 Pm "+"\nHour:"+time+"\nMonth:"+month); 	
       }else{
    	   calendar.set(Calendar.HOUR_OF_DAY, 16);
           calendar.set(Calendar.MINUTE,0);
    	  // tv.setText("next Prayer is Asar 4--> Pm "+"\nHour:"+time+"\nMonth:"+month+"\nMin:"+min);
    }
    	manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                1000 * 60 * 1, pendingIntent2);
        Toast.makeText(this, " alarm set for Asar !!!", Toast.LENGTH_SHORT).show();
    }
    public void Magrib(){
    	AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        
        alarmIntent = new Intent(MyActivity.this, AlarmReceiver.class);
       Bundle extras = new Bundle();
 		extras.putString("id", "40");	
 		alarmIntent.putExtras(extras);
       
       //alarmIntent.putExtra("getX", "2");
         PendingIntent pendingIntent2 = PendingIntent.getBroadcast(MyActivity.this, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
         Calendar calendar = Calendar.getInstance();
         calendar.setTimeInMillis(System.currentTimeMillis());
    	if(month==1){
    		calendar.set(Calendar.HOUR_OF_DAY, 17);
            calendar.set(Calendar.MINUTE,20);
    		//tv.setText("next Prayer is magrib 5:20 Pm "+"\nHour:"+time+"\nMonth:"+month);
          }else if(month==2 || month==9){
        	  calendar.set(Calendar.HOUR_OF_DAY, 17);
              calendar.set(Calendar.MINUTE,40);
        	//  tv.setText("next Prayer is magrib 5:40 Pm "+"\nHour:"+time+"\nMonth:"+month);
          }else if(month==3 || month==4){
        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
              calendar.set(Calendar.MINUTE,0);
        	 // tv.setText("next Prayer is magrib 6 Pm "+"\nHour:"+time+"\nMonth:"+month);
          }else if(month==5){
        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
              calendar.set(Calendar.MINUTE,20);
        	//  tv.setText("next Prayer is magrib 6:20 Pm "+"\nHour:"+time+"\nMonth:"+month);          
          }else if(month==6 || month==7){
        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
              calendar.set(Calendar.MINUTE,40);
        	 // tv.setText("next Prayer is magrib 6:40 Pm "+"\nHour:"+time+"\nMonth:"+month+"\nmin:"+min); 
          }else if(month==8){
        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
              calendar.set(Calendar.MINUTE,10);
        	//  tv.setText("next Prayer is magrib 6:10 Pm "+"\nHour:"+time+"\nMonth:"+month);         
          }else{
        	  calendar.set(Calendar.HOUR_OF_DAY, 17);
              calendar.set(Calendar.MINUTE,0);
        	//  tv.setText("next Prayer is magrib 5 Pm "+"\nHour:"+time+"\nMonth:"+month); 
          }
    	 manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                 1000 * 60 * 1, pendingIntent2);
         Toast.makeText(this, " alarm set for Magrib !!!", Toast.LENGTH_SHORT).show();
    	
    }
    public void Esha(){
    	AlarmManager manager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        
        alarmIntent = new Intent(MyActivity.this, AlarmReceiver.class);
       Bundle extras = new Bundle();
 		extras.putString("id", "50");	
 		alarmIntent.putExtras(extras);
       
       //alarmIntent.putExtra("getX", "2");
         PendingIntent pendingIntent2 = PendingIntent.getBroadcast(MyActivity.this, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
         Calendar calendar = Calendar.getInstance();
         calendar.setTimeInMillis(System.currentTimeMillis());
         calendar.set(Calendar.HOUR_OF_DAY, 21);
         calendar.set(Calendar.MINUTE,30);
         manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                 1000 * 60 * 1, pendingIntent2);
         Toast.makeText(this, " alarm set for Esha !!!", Toast.LENGTH_SHORT).show();
    	// tv.setText("next Prayer is Esha 9:30 Pm "+"\nHour:"+time+"\nMonth:"+month); 
    	
    }
    public void getPreferences(){
    	if(F.isChecked()){
			fAzar="true";
			// F.setChecked(true);
		}
		if(!F.isChecked()){
			
			fAzar="false";
		}
		if(Z.isChecked()){
			zOhor="true";
		}if(!Z.isChecked()){
			zOhor="false";
		}
		if(A.isChecked()){
			aSar="true";
		}if(!A.isChecked()){
			aSar="false";
		}
		if(M.isChecked()){
			mAgrib="true";
		}if(!M.isChecked()){
			mAgrib="false";
		}
		if(E.isChecked()){
			eSha="true";
		}if(!E.isChecked()){
			eSha="false";
		}
	  //  shf= getSharedPreferences("MyData",Context.MODE_PRIVATE);
        SharedPreferences.Editor edit=shf.edit();
        edit.putString("fazar",fAzar);
        edit.putString("zohor",zOhor);
        edit.putString("asar",aSar);
        edit.putString("magrib",mAgrib);
        edit.putString("esha",eSha);
        edit.commit();
       // Toast.makeText(getApplicationContext(), "Data Saved To SP!!!", Toast.LENGTH_LONG).show();
    }
    
    public void showPreferences(){
    	  try{
         	 shf2= getSharedPreferences("MyData",Context.MODE_PRIVATE);
         	 r1=shf2.getString("fazar", DEFAULT);
         	 r2=shf2.getString("zohor", DEFAULT);
         	 r3=shf2.getString("asar", DEFAULT);
         	 r4=shf2.getString("magrib", DEFAULT);
         	 r5=shf2.getString("esha", DEFAULT);
         	
         	if(r1.equals(DEFAULT) || r2.equals(DEFAULT) ||r3.equals(DEFAULT) || r4.equals(DEFAULT) || r5.equals(DEFAULT)){
         		//Toast.makeText(getApplicationContext(), "Default ValueS!!!", Toast.LENGTH_LONG).show();
         		if(r1.equals("true")){
         			//faz.setTextColor(Color.GREEN);
          		  // faz.setText("running");
          		 F.setChecked(true);
          		// faz.setTextColor(Color.GREEN);
          		 //faz.setTextColor(Color.GREEN);
          		 
          	   }if(!(r1.equals("true"))){
          		// faz.setTextColor(Color.RED);
          		// faz.setTextColor(Color.RED);
          		  // faz.setText("OF");
          		 F.setChecked(false);
          	   }
         		if(r2.equals("true")){
         		  // zoh.setTextColor(Color.BLUE);
           		  // zoh.setText("running");
           		Z.setChecked(true);
           	   }else{
           		//zoh.setTextColor(Color.RED);
           		 //  zoh.setText("OF");
           		Z.setChecked(false);
           	   }if(r3.equals("true")){
           		  // asa.setTextColor(Color.YELLOW);
          		  // asa.setText("running");
          		 A.setChecked(true);
          	   }else{
          		// asa.setTextColor(Color.RED);
          		  // asa.setText("OF");
          		 A.setChecked(false);
          	   }if(r4.equals("true")){
          		 //  mag.setTextColor(Color.MAGENTA);
          		//   mag.setText("running");
          		 M.setChecked(true);
          	   }else{
          		 //mag.setTextColor(Color.RED);
          		  // mag.setText("OF");
          		 M.setChecked(false);
          	   }if(r5.equals("true")){
          		   
          		 //  esh.setText("running");
          		 E.setChecked(true);
          		 //esh.setTextColor(Color.GRAY);
          	   }else{
          		// esh.setTextColor(Color.RED);
          		// esh.setTextColor(Color.MAGENTA);
          		  // esh.setText("OF");
          		 E.setChecked(false);
          	   }
         		
         	}else{
         	//	Toast.makeText(getApplicationContext(), "getting Data 4rm SP !!!", Toast.LENGTH_LONG).show();
         		
         		if(r1.equals("true")){
           		  // faz.setText("running");
           		    F.setChecked(true);
           		   
           	   }else{
           		  // faz.setText("OF");
           		F.setChecked(false);
           	   }
          		if(r2.equals("true")){
            		//   zoh.setText("running");
            		   Z.setChecked(true);
            		   
            	   }else{
            		  // zoh.setText("OF");
            		   Z.setChecked(false);
            	   }if(r3.equals("true")){
           		 //  asa.setText("running");
           		A.setChecked(true);
           	   }else{
           		 //  asa.setText("OF");
           		A.setChecked(false);
           	   }if(r4.equals("true")){
           		   //mag.setText("running");
           		   
           		M.setChecked(true);
           	   }else{
           		   //mag.setText("OF");
           		M.setChecked(false);
           	   }if(r5.equals("true")){
           		   //esh.setText("running");
           		E.setChecked(true);
           	   }else{
           		   //esh.setText("OF");
           		E.setChecked(false);
           	   }
         	}
         	
         }catch(Exception E){
         	Toast.makeText(getApplicationContext(), ""+E, Toast.LENGTH_LONG).show();
         }
    }

   

}



