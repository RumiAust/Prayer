package com.javatechig.alarmservice;

import android.app.ActionBar;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Dua extends ListActivity{
	static final String[] MOBILE_OS = 
            new String[] { "Special Dua", "Zikir", "Dress Code", "Sunnoti Dress"};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ActionBar acBar= getActionBar();
		acBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0066FF")));
		setListAdapter(new ListArrayAdapter(this,MOBILE_OS) );
		//ListArrayAdapter(getActivity, MOBILE_OS, "SolaimanLipi-8-Jan-2011.ttf");

	}

	
	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {

		//get selected items
		String selectedValue = (String) getListAdapter().getItem(position);
		//Toast.makeText(this, selectedValue, Toast.LENGTH_LONG).show();
		if(selectedValue.equals("Special Dua")){
			dialogBox("Special Dua ","All details of Special  Dua");
		}
      if(selectedValue.equals("Zikir")){
    	  dialogBox("Zikir ","All details of Zikir");
		}
      if(selectedValue.equals("Dress Code")){
    	  dialogBox("Dress Code ","All details of Dress Code");
      }
      if(selectedValue.equals("Sunnoti Dress")){
    	  dialogBox("Sunnoti Dress ","All details of Sunnoti Dress ");
      }
		

	}
	public void dialogBox(String title,String msg){
		final Dialog d = new Dialog(this);
	  	d.setContentView(R.layout.customdialogbox);
		d.setTitle(title);
		TextView txt=(TextView)d.findViewById(R.id.tv1);
		txt.setText(msg);
		 Button b =(Button)d.findViewById(R.id.dialogButtonOK);
		b.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				d.dismiss();
			}
			
		});
		
		d.show();
	}
}
