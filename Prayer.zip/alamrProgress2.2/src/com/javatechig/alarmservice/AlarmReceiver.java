package com.javatechig.alarmservice;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class AlarmReceiver extends BroadcastReceiver {
  int x=0;
  final static int dialog_id=0;
  public int flag=0;
  String fazarChecked;
    double time;
	double month;
	double min;
	String info;
	private String r1,r2,r3,r4,r5;
	SharedPreferences  shf2;
	public static final String DEFAULT ="N?A";
	Random randomGenerator = new Random();
    @Override
     
    public void onReceive(Context context, Intent intent2) {
    	
    	
               info=intent2.getExtras().getString("id");
		String info1=intent2.getExtras().getString("city");
		String info2=intent2.getExtras().getString("place");
	    fazarChecked=intent2.getExtras().getString("isChecked");
	    //shf= getSharedPreferences("MyData",Context.MODE_PRIVATE);
	    try{
	    	shf2= context.getSharedPreferences("MyData",Context.MODE_PRIVATE);
         	 r1=shf2.getString("fazar", DEFAULT);
         	 r2=shf2.getString("zohor", DEFAULT);
         	 r3=shf2.getString("asar", DEFAULT);
         	 r4=shf2.getString("magrib", DEFAULT);
         	 r5=shf2.getString("esha", DEFAULT);
         //	 Log.d("values",r1+"\n"+r2+"\n"+r3+"\n"+r4+"\n"+r5);
	    }catch(Exception e){
	    	
	    }
	    Calendar cx = Calendar.getInstance();
		SimpleDateFormat hh = new SimpleDateFormat("HH");
		SimpleDateFormat mm = new SimpleDateFormat("MM");
		SimpleDateFormat mi = new SimpleDateFormat("mm");
		        
		        String strHour = hh.format(cx.getTime());
		        String strMonth = mm.format(cx.getTime());
		        String strMin = mi.format(cx.getTime());
		        try{
		            double x=Double.parseDouble(strHour);
		            double y=Double.parseDouble(strMonth);
		            double z=Double.parseDouble(strMin);
		             time=x;
		             month=y;
		             min=z;
		            }catch(Exception e){
		            	Toast.makeText(context,""+e, Toast.LENGTH_LONG).show();
		            }
		//Toast.makeText(context, "ID: "+info, Toast.LENGTH_LONG).show();

        // For our recurring task, we'll just display a message
    	Intent intent= new Intent();
    	x++;

    	if(info.equals("10")){
    		try{
    			if(r1.equals("true")){
    			getNotification(context, intent);
    			}
      
		//-------------Set New Alarm Here And Pass The NExt Next value------------------------------------------
		AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
      Intent alarmIntent = new Intent(context, AlarmReceiver.class);
      Bundle extras = new Bundle();
		extras.putString("id", "20");	
		alarmIntent.putExtras(extras);
      
      //alarmIntent.putExtra("getX", "2");
        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY, 13);
        calendar.set(Calendar.MINUTE,0);
        manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                1000 * 60 * 1, pendingIntent2);
        Toast.makeText(context, " alarm set for Zohor !!!", Toast.LENGTH_SHORT).show();
 
    		}catch(Exception e){
    			Toast.makeText(context, " "+e, Toast.LENGTH_SHORT).show();
    		}
    		
    	} //------------ZOHOR--------------
           else if(info.equals("20")){
        	   if(r2.equals("true")){
        	   getNotification(context, intent);
        	   }
    		//Toast.makeText(context, "working for ZOHOR alarm", Toast.LENGTH_SHORT).show();
    		AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    	      Intent alarmIntent = new Intent(context, AlarmReceiver.class);
    	      Bundle extras = new Bundle();
    			extras.putString("id", "30");	
    			alarmIntent.putExtras(extras);
    	      
    	      //alarmIntent.putExtra("getX", "2");
    	        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
    	        Calendar calendar = Calendar.getInstance();
    	        calendar.setTimeInMillis(System.currentTimeMillis());
    	        if(month==10 || month==11 || month==12 || month==1){
    	    		calendar.set(Calendar.HOUR_OF_DAY, 15);
    	            calendar.set(Calendar.MINUTE,30);
    	    		//tv.setText("next Prayer is Asar 3:30 Pm "+"\nHour:"+time+"\nMonth:"+month); 	
    	       }else{
    	    	   calendar.set(Calendar.HOUR_OF_DAY, 16);
    	           calendar.set(Calendar.MINUTE,0);
    	    	  // tv.setText("next Prayer is Asar 4--> Pm "+"\nHour:"+time+"\nMonth:"+month+"\nMin:"+min);
    	    }
    	        manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
    	                1000 * 60 * 1, pendingIntent2);
    	        Toast.makeText(context, " alarm set Asar !!!", Toast.LENGTH_SHORT).show();

    	}//------------------ASAR---------------------
           else if(info.equals("30")){
        	   if(r3.equals("true")){
        	   getNotification(context, intent);
        	   }
    		//Toast.makeText(context, "working for ASAR alarm", Toast.LENGTH_SHORT).show();
    		AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    	      Intent alarmIntent = new Intent(context, AlarmReceiver.class);
    	      Bundle extras = new Bundle();
    			extras.putString("id", "40");	
    			alarmIntent.putExtras(extras);
    	      
    	      //alarmIntent.putExtra("getX", "2");
    	        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
    	        Calendar calendar = Calendar.getInstance();
    	        calendar.setTimeInMillis(System.currentTimeMillis());
    	        if(month==1){
    	    		calendar.set(Calendar.HOUR_OF_DAY, 17);
    	            calendar.set(Calendar.MINUTE,20);
    	    		//tv.setText("next Prayer is magrib 5:20 Pm "+"\nHour:"+time+"\nMonth:"+month);
    	          }else if(month==2 || month==9){
    	        	  calendar.set(Calendar.HOUR_OF_DAY, 17);
    	              calendar.set(Calendar.MINUTE,40);
    	        	//  tv.setText("next Prayer is magrib 5:40 Pm "+"\nHour:"+time+"\nMonth:"+month);
    	          }else if(month==3 || month==4){
    	        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
    	              calendar.set(Calendar.MINUTE,0);
    	        	 // tv.setText("next Prayer is magrib 6 Pm "+"\nHour:"+time+"\nMonth:"+month);
    	          }else if(month==5){
    	        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
    	              calendar.set(Calendar.MINUTE,20);
    	        	//  tv.setText("next Prayer is magrib 6:20 Pm "+"\nHour:"+time+"\nMonth:"+month);          
    	          }else if(month==6 || month==7){
    	        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
    	              calendar.set(Calendar.MINUTE,40);
    	        	 // tv.setText("next Prayer is magrib 6:40 Pm "+"\nHour:"+time+"\nMonth:"+month+"\nmin:"+min); 
    	          }else if(month==8){
    	        	  calendar.set(Calendar.HOUR_OF_DAY, 18);
    	              calendar.set(Calendar.MINUTE,10);
    	        	//  tv.setText("next Prayer is magrib 6:10 Pm "+"\nHour:"+time+"\nMonth:"+month);         
    	          }else{
    	        	  calendar.set(Calendar.HOUR_OF_DAY, 17);
    	              calendar.set(Calendar.MINUTE,0);
    	        	//  tv.setText("next Prayer is magrib 5 Pm "+"\nHour:"+time+"\nMonth:"+month); 
    	          }
    	        manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
    	                1000 * 60 * 1, pendingIntent2);
    	        Toast.makeText(context, " alarm set MAGRIB !!!", Toast.LENGTH_SHORT).show();
	
    	}//-------------------MAGRIB--------
           else if(info.equals("40")){
        	   if(r4.equals("true")){
        	   getNotification(context, intent);
        	   }
    		//Toast.makeText(context, "working for MAGRIB alarm", Toast.LENGTH_SHORT).show();
    		AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    	      Intent alarmIntent = new Intent(context, AlarmReceiver.class);
    	      Bundle extras = new Bundle();
    			extras.putString("id", "50");	
    			alarmIntent.putExtras(extras);
    	      
    	      //alarmIntent.putExtra("getX", "2");
    	        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
    	        Calendar calendar = Calendar.getInstance();
    	        calendar.setTimeInMillis(System.currentTimeMillis());
    	        calendar.set(Calendar.HOUR_OF_DAY, 21);
    	        calendar.set(Calendar.MINUTE,30);
    	        manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
    	                1000 * 60 * 1, pendingIntent2);
    	        Toast.makeText(context, " alarm set ESHA !!!", Toast.LENGTH_SHORT).show();
	
    	}//-------------------ESHA-----------------
           else if(info.equals("50")){
        	   int y=0;
        	   try{
        		   if(r5.equals("true")){
        		   getNotification(context, intent);
        		   }
        		  // Toast.makeText(context, "working for ESHA alarm", Toast.LENGTH_SHORT).show();
           		AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
           	      Intent alarmIntent = new Intent(context, AlarmReceiver.class);
           	      Bundle extras = new Bundle();
           			extras.putString("id", "10");	
           			alarmIntent.putExtras(extras);
           	      
           	      
           	        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT);
           	        Calendar calendar = Calendar.getInstance();
           	       //------------increment day for fazar namaz!!!
           	     Calendar c = Calendar.getInstance();
                 c.add(Calendar.DATE, 1);
                 //SimpleDateFormat sdf = new SimpleDateFormat("MM/DD/yyyy hh:mm:ss a");
                 SimpleDateFormat sdf = new SimpleDateFormat("dd");
                 String strDate = sdf.format(c.getTime());
                 try{
                 int x=Integer.parseInt(strDate);
                  y=x;
                 }catch(Exception e){
                	 Toast.makeText(context, " "+e, Toast.LENGTH_SHORT).show();
                 }
           	        //set time after increment day 
           	        calendar.setTimeInMillis(System.currentTimeMillis());
           	        
           	     if(month==1 || month==2 || month==12){
           	    	calendar.set(Calendar.DAY_OF_MONTH, y);
           	    	calendar.set(Calendar.HOUR_OF_DAY, 5);
           	        calendar.set(Calendar.MINUTE,0);
           	     }else if(month==5 || month==6){
           	    	calendar.set(Calendar.DAY_OF_MONTH, y);
           	    	calendar.set(Calendar.HOUR_OF_DAY, 3);
           	        calendar.set(Calendar.MINUTE,0);
           	     }else{
           	    	calendar.set(Calendar.DAY_OF_MONTH, y);
           	    	calendar.set(Calendar.HOUR_OF_DAY, 3);
           	        calendar.set(Calendar.MINUTE,45);
           	     }
           	        
           	        manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
           	                1000 * 60 * 1, pendingIntent2);
           	        Toast.makeText(context, " alarm set FOZOR !!!"+y, Toast.LENGTH_SHORT).show();	
        	   }catch(Exception e){
        		   Toast.makeText(context, " "+e, Toast.LENGTH_SHORT).show();	   
        	   }
    		
    	      /*  if (manager!= null) {
      	            manager.cancel(pendingIntent2);
      	            Toast.makeText(context, "Alarm is Now cancelled!! :", Toast.LENGTH_SHORT).show();
      	        }*/
    	}
    	else{
    		Toast.makeText(context, "Not AnyThing found !!!!", Toast.LENGTH_SHORT).show();
    		AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
  	      Intent alarmIntent = new Intent(context, AlarmReceiver.class);
  	      
  	        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, 0, alarmIntent, 0);
  	        if (manager!= null) {
  	            manager.cancel(pendingIntent2);
  	            Toast.makeText(context, "Alarm is Now cancelled!! :", Toast.LENGTH_SHORT).show();
  	        }
    		
    	}
    }
    public void getNotification(Context context,Intent intent){
    	try{
    		 int icon = R.drawable.zakat;
    			long when = System.currentTimeMillis();
    			NotificationManager notificationManager = (NotificationManager) context
    					.getSystemService(Context.NOTIFICATION_SERVICE);
    			Notification notification = new Notification(icon," ", when);
    			intent =new Intent(context,NfTest.class);
    			String msg =getHadith();
    			intent.putExtra("id1",msg);
    			
    			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_SINGLE_TOP);
    			
    			PendingIntent otifyIntent=PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    			

    			String title = context.getString(R.string.app_name);
    			notification.setLatestEventInfo(context, title, "Tab To See The Hadith", otifyIntent);
    			notification.flags |= Notification.FLAG_AUTO_CANCEL;

    			// Play default notification sound
    			notification.defaults |= Notification.DEFAULT_SOUND;
    			// Vibrate if vibrate is enabled
    			notification.defaults |= Notification.DEFAULT_VIBRATE;
    			notificationManager.notify(0, notification);
    	}catch(Exception e){
    		
    	}
    }
    public String getHadith(){
    	String result="";
    	String data[]={
 			   "আমি আপনার নিকট ওহী প্রেরণ করেছি যেমন নূহ ও তার পরবর্তী নবী গণের নিকট প্রেরণ করেছিলাম । (৪:১৬৩ )",//1
 			   "আল্লাহ্‌ তা’আলা ইরশাদ করেনঃ “যাতে তারা তাদের ঈমানের সাথে ঈমান দৃঢ় করে নেয় (৪৮:৪) ",//2
 			   "এবং যারা সৎপথে চলে আল্লাহ্‌ তাদের অধিক হিদায়ত দান করেন (১৯:৭৬)",//3
 			   "উবায়দুল্লাহ ইবন মুসা (রাঃ)......ইবন উমর (রাঃ) থেকে বর্ণিত, তিনি বলেন, রাসুলুল্লাহ (সা) ইরশাদ করেন, ইসলামের ভিত্তি পাচটি ।" +//4
 			   " ১ আল্লাহ ছাড়া ইলাহ নেই এবং নিশ্চয়ই মুহাম্মদ (সা) আল্লাহর রাসুল-এ কথার সাক্ষ্য দান । ২ সালাত কায়েম করা। ৩। যাকাত দেওয়া । ৪ হজ্জ করা এবং ৫ রমদান-এর সিয়াম পালন করা। -সহীহ বুখারী, হাদীস নং- ৭",
 			   
 			   "আবুল ইয়ামান (র)......আবু হুরায়রা (রাঃ) থেকে বর্ণিত, রাসুলুল্লাহ (সা) ইরশাদ করেনঃ সে পবিত্র সত্তার কসম, যার হাতে আমার প্রাণ, " +//5
 			   "তোমাদের কেউ প্রকৃত মুমিন হতে পারবে না যতক্ষন না আমি তার কাছে তাহার পিতা ও সন্তানের চেয়ে বেশী প্রিয় হই ।-সহীহ বুখারী, হাদীস নং- ১৩",
 			  //6
 			   "হুমায়দী (র)……আল কামা ইবন ওয়াকাস আল লায়সী (র) থেকে বর্ণিত- আমি উমর ইবনুল খাত্তাব (রাঃ)-কে মিন্বরের ওপর দাড়িয়ে বলতে শুনেছি: আমি রাসুলুল্লাহ (সা) কে ইরশাদ করতে শুনেছি:" +
 			   " প্রত্যেক কাজ নিয়তের সাথে সম্পর্কিত ।" +
 			   " আর মানুষ তার নিয়ত অনুযায়ী ফল পাবে । তাই যার হিজরত হবে দুনিয়া লাভের অথবা কোন নারীকে বিয়ে করার উদ্দেশ্যে-সেই উদ্দেশ্যই হবে তার হিজরতের প্রাপ্য ।--সহীহ বুখারী, হাদীস নং- ১",
 			   //7
 			   "মুহাম্মদ ইবনে সালাম (র)......আয়িশা (রা) থেকে বর্ণিত, উম্মে সালমা (রা) রাসূলুল্লাহ (সা) কাছে তাঁর হাবশায় দেখা মারিয়া নামক একটা গির্জার কথা " +
 			   "উল্লেখ করলেন। তিনি সেখানে যে সব প্রতিচ্ছবি দেখে ছিলেন, সেগুলোর বর্ণনা দিলেন। তখন রাসূলুল্লাহ (সা) বললেন এরা এমন সম্প্রদায় যে, এদের মধ্যে কোন সৎ" +
 			   " বান্দা অথবা বলেছেন কোন সৎ লোক মারা গেলে তার কবরের উপর তারা মসজিদ বানিয়ে নিত। আর তাতে ঐ সব ব্যক্তির প্রতিচ্ছবি স্থাপন করতো। এরা আল্লাহর কাছে নিকৃষ্ট সৃষ্টি।-সহীহ বুখারী, হাদীস নং-৪২২",
 			   //8
 			   "ইয়াহইয়া ইবনু বুকায়র (রহঃ) যায়দ ইবনু খালিদ (রাঃ) থেকে বর্ণিত যে, রাসূল (সাল্লাল্লাহু আলাইহি ওয়া সাল্লাম) অবিবাহিত ব্যভিচারী সম্পর্কে একশ বেত্রাঘাত এবং এক বছরের নির্বাসনের নির্দেশ দিয়েছেন।-সহিহ বুখারী, হাদীস নং-২৪৭৩",
 			   //9
 			   "আবদুল্লাহ্‌ ইব্‌ন ইউসুফ (র.)......আবূ হুরায়রা (রা.) থকে বর্ণিত, তিনি বলেন, রাসূলুল্লাহ্‌ (সা.) বলেছেনঃ যখন সালাতের জন্য আযান দেওয়া হয়, তখন শয়তান হাওয়া ছেড়ে " +
 			   "পলায়ণ করে, যাতে সে আযানের শব্দ না শোনে। যখন আযান শেষ হয়ে যায়, তখন সে আবার ফিরে আসে। আবার যখন সালাতের জন্য ইকামত বলা হয়, তখন আবার দূরে সরে যায়। " +
 			   "ইকামত শেষ হলে সে পুনরায় ফিরে এসে লোকের মনে কুমন্ত্রণা দেয় এবং বলে এটা স্মরণ কর, ওটা স্মরণ কর, বিস্মৃত বিষয়গুলো সে স্মরণ করিয়ে দেয়। এভাবে লোকটি এমন পর্যায়ে পৌছে" +
 			   " যে, সে কয় রাকাআত সালাত আদায় করেছে তা মনে করতে পারে না।-সহীহ বুখারী, হাদীস নং-৫৮১.",
 			   //10
 			   "আবদুল্লাহ্ ইবন ইউসুফ (র.).......... আবূ হুরায়রা (রা.) থেকে বর্ণিত যে, রাসূলুল্লাহ (সাঃ) বলেছেনঃ যকন তোমাদের কেউ (সালাতে) ‘আমীন’ বলে, আর আসমানে ফিরিশতাগণ ‘আমীন’" +
 			   " বলেন এবং উভয়ের ‘আমীন’ একই সময় হলে, তার পূর্ববর্তী সব গুনাহ মা’ফ করে দেওয়া হয়।-সহীহ বুখারী, হাদীস নং-745",
 			   //11
 			   "আল্লাহ নিজ অনুগ্রহে যা তাদেরকে দিয়েছেন তাতে যারা কৃপনতা করে, তাদের জন্য তা মঙ্গল এ যেন তারা কিছুতেই মনে না করে। -[আল-ইমরানঃ ১৮০]",
 			   //12
 			   "দুর্ভোগ (ধংস ) অনিবার্য ঐ সকল মুশরিকদের জন্য যারা যাকাত আদায় করে না এবং আখিরাতেও অবিশ্বাসী।–[ হামিমঃ ৬ ও ৭]",
 			   //13
 			   "তাদের সম্পদ থেকে সাদাকা (যাকাত ) গ্রহন করুন। এর দ্বারা আপনি তাদেরকে পবিত্র , করবেন এবং পরিশোধিত করবেন । -[তওবাঃ ১০৩]",
 			   //14
 			   "সালাত কায়েম কর, যাকাত আদায় কর, রাসূলের আনুগত্য কর, যাতে করে তোমরা আল্লাহ্র রহমত পেতে পার। -[নূরঃ ৫৬]",
 			   //15
 			   "তোমরা নামাজ কায়েম কর এবং যাকাত দাও।- [বাকারাহঃ ৪৩ ও ১১০]",
 			   //16
 			   "আমর ইবন হাফস ইবন গিয়াছ (র)......আবু হুরায়রা (রাঃ) সুত্রে নবী (সা) থেকে বর্ণিত । তিনি বলেনঃ চোরের " +
 			   "উপর আল্লাহর লাঁনত নিপতিত হয়, যখন সে একটি ডিম চুরি করে এবং এর জন্য তার হাত কাটা যায় এবং সে একটি রশি চুরি করে । " +
 			   "এর জন্য তার হাত কাটা যায় । আমাশ (র) বলেনঃ ডিম দ্বারা লোহার টুকরা-এবং রশি দ্বারা কয়েক দিরহাম মুল্যমানের রশিকে" +
 			   " বোঝানো হয়েছে ।-সহীহ বুখারী, হাদীস নং-৬৩২৬",
 			   //17
 			   "আর তিনিই সেই সত্তা, যিনি সৃষ্টিকে অসিত্মত্ব আনয়ন করেন, আবার তিনিই তা সৃষ্টি করবেন পুনর্বার; আর তা তাঁর জন্য অতি সহজ। (র্সরা রূমঃ ২৭)",
 			   //18
 			   "কুতাইবা (র)................আবূ হুরায়রা (রা) থেকৈ বর্ণিত, তিনি বলেন, রাসূলুল্লাহ (সাঃ) বলেছেন, আল্লাহ যখন সৃষ্টি কার্য সমাধা করলেন," +
 			   " তখন তিনি তাঁর কিতাব লাওহে মাহফুজে লিখেন, যা আরশের কাছে তাঁর উপর বিদ্যমান। নিশ্চই আমার করুণা আমার ক্রোধের চেয়ে প্রবল।-সহীহ বুখারী, হাদীস নং-২৯৬৪",
 			   //19
 			   "সাঈদ ইব্ন আবূ মারয়ম (র).................সাহল ইব্ন সাদ (রা) থেকে বর্ণিত, নবী (সাঃ) বলেছেন, ‘জান্নাতে আটটি দরজা থাকবে। " +
 			   "তন্মধ্যে একটি দরজার নাম হবে রাইয়্যান। একমাত্র রোযাদারগণই এ দরজা দিয়ে জান্নাতে প্রবেশ করবে।-সহীহ বুখারী, হাদীস নং-৩০২৬",
 			   //20
 			   "আবদুল্লাহ ইব্ন মাসলামা (র)..............আবদুল্লাহ ইব্ন উমর (রা) থেকে বর্ণিত। রাসূলুল্লাহ (সাঃ) বলেছেন, পাঁচ প্রকারের অনিষ্টকারী প্রাণী" +
 			   " যাদেরকে কেউ ইহরাম অবস্থায়ও যদি মেরে ফেলে, তা হলে তার কোন গুনাহ নেই। এগুলো হল বিচ্ছু, ইঁদুর, পাগলা কুকুর, কাক এবং চিল।-সহীহ বুখারী, হাদীস নং-৩০৭৮",
 			   //21
 			   " তুমি কি সে লোককে দেখনি, যে পালনকর্তার ব্যাপারে বাদানুবাদ করেছিল ইবরাহীমের সাথে এ কারণে যে, আল্লাহ্ সে ব্যক্তিকে রাজ্য দান করেছিলেন ?" +
 			   " ইবরাহীম যখন বললেন, আমার প্রতিপালক হলেন তিনি, যিনি জীবন দান করেন এবং মৃত্যু ঘটান। সে বলল, আমিও জীবন দান করি এবং মৃত্যু ঘটিয়ে থাকি। " +
 			   "ইবরাহীম বললেন, নিশ্চয়ই তিনি সূর্যকে উদিত করেন পূর্ব দিক থেকে এবার তুমি তাকে পশ্চিম দিক থেকে উদিত কর। তখন সে কাফের হতভম্ব হয়ে গেল। আর" +
 			   " আল্লাহ্ সীমালংঘণকারী সম্প্রদায়কে সরল পথ প্রদর্শ করেন না।-বাকারা-২৫৮",
 			   //22
 			   "data not found"};
 	  int randomInt = randomGenerator.nextInt(22);
 	 if(info.equals("10")){
        result="ফজর নামায এর ওয়াক্ত  কিছুখন পর শুরু হবে:\n\n"+data[randomInt]+"\n\nকেমন করে তোমরা আল্লাহ্র ব্যাপারে কুফরী অবলম্বন করছ?" +
        		" অথচ তোমরা ছিলে নি®প্রাণ। অতঃপর তিনিই তোমাদেরকে প্রাণ দান করেছেন আবার মৃত্যু দান করবেন। পুনরায় তোমাদেরকে জীবনদান করবেন। " +
        		"অতঃপর তারই প্রতি প্রত্যাবর্তন করবে।-বাকারা-২৮";
 	 }
 	if(info.equals("20")){
        result="যোহর এর নামায এর ওয়াক্ত হয়ে শুরু হয়েছে:\n\n"+data[randomInt]+"\n\nআর এমন লোকদের জন্য কোন ক্ষমা নেই, যারা মন্দ কাজ করতেই থাকে, " +
        		"এমন কি যখন তাদের কারো মাথার ওপর মৃত্যু উপস্থিত হয়, তখন বলতে থাকে আমি এখন তওবা করছি। আর তওবা নেই তাদের জন্য," +
        		" যারা কুফরী অবস্থায় মৃত্যুবরণ করে। আমি তাদের জন্য যন্ত্রণাদায়ক শাস্তি প্রস্তুত করে রেখেছি।-নিসা-১৮";;
 	 }
 	if(info.equals("30")){
        result="আছর এর ওয়াক্ত  শুরু হয়েছে :\n\n"+data[randomInt]+"\n\nনিশ্চয় যারা কুফরী করে এবং কাফের অবস্থায়ই মৃত্যুবরণ করে, " +
        		"সে সমস্ত লোকের প্রতি আল্লাহ্র ফেরেশতাগণের এবং সমগ্র মানুষের লা’নত।-বাকারা-১৬১";
 	 }
 	if(info.equals("40")){
        result="একটু পর মাগরিব এর নামায: \n\n"+data[randomInt]+"\n\nআর তোমরা মৃত্যুই বরণ কর অথবা নিহতই হও," +
        		" অবশ্য আল্লাহ্র সামনেই সমবেত হবে।-আলে ইমরান-১৫৭";
 	 }
 	if(info.equals("50")){
        result="এশার নামায:\n\n"+data[randomInt]+"\n\nপ্রত্যেক প্রাণীকে আস্বাদন করতে হবে মৃত্যু। আর তোমরা কিয়ামতের " +
        		"দিন পরিপূর্ণ বদলা প্রাপ্ত হবে। তারপর যাকে দোজখ থেকে দূরে রাখা হবে এবং জান্নাতে প্রবেশ করানো হবে, তার কার্যসিদ্ধি ঘটবে।" +
        		" আর পার্থিব জীবন ধোঁকা ছাড়া অন্য কোন সম্পদ নয়।-আলে ইমরান-১৮৫";
 	 }
    	return result;
    }
} 