package com.javatechig.alarmservice;
import android.app.Activity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class SetDistrict extends Activity{
	private RadioGroup radioGroup; 
	String dis="Dhaka";
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.district);
		radioGroup = (RadioGroup) findViewById(R.id.myRadioGroup);
		
		radioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// find which radio button is selected
				if(checkedId == R.id.Dha) {
					dis="Dhaka";
					Toast.makeText(getApplicationContext(), ""+dis, 
							Toast.LENGTH_SHORT).show();
				} else if(checkedId == R.id.Chi) {
					dis="chittagong";
					Toast.makeText(getApplicationContext(), ""+dis, 
							Toast.LENGTH_SHORT).show();
				} else if(checkedId == R.id.Bar) {
					dis="Barisal";
					Toast.makeText(getApplicationContext(), ""+dis, 
							Toast.LENGTH_SHORT).show();
				}  else if(checkedId == R.id.Jam) {
					dis="Jamalpur";
					Toast.makeText(getApplicationContext(), ""+dis, 
							Toast.LENGTH_SHORT).show();
				}  else if(checkedId == R.id.Ran) {
					dis="Rangpur";
					Toast.makeText(getApplicationContext(), ""+dis, 
							Toast.LENGTH_SHORT).show();
				} 
				else if(checkedId == R.id.Raj) {
					Toast.makeText(getApplicationContext(), ""+dis, 
							Toast.LENGTH_SHORT).show();
				}else {
					dis="No District Found";
					Toast.makeText(getApplicationContext(), ""+dis, 
							Toast.LENGTH_SHORT).show();
				}
			}
			
		});
	}
	public String getDis(){
		return dis;
	}
}
