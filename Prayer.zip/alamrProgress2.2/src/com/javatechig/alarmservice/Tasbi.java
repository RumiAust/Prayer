package com.javatechig.alarmservice;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Tasbi extends Activity{
	TextView century,total;
	Button btn,clr;
	double count=0,cenCount=0,totalCount=0;
	private Vibrator vibrator;
	Typeface font;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tasbi);
		century=(TextView)findViewById(R.id.hundred);
		total=(TextView)findViewById(R.id.totalpresses);
		btn=(Button) findViewById(R.id.tasbibtn);
		clr=(Button) findViewById(R.id.buttonclear);
		font = Typeface.createFromAsset(getAssets(),"SolaimanLipi-8-Jan-2011.ttf");
		btn.setOnClickListener(new View.OnClickListener() {
			Vibrator vibe =  (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            @Override
            public void onClick(View v) {
            	
            	//vibe.vibrate(100);
            	//btn.getBackground().setColorFilter(new LightingColorFilter(0xFFFFFFFF, 0xFFAA0000));
            	count++;
            	totalCount++;
            	if(count==100){
            		vibe.vibrate(100);
            		cenCount++;
                    count=0;
            	}
            	century.setTypeface(font);
            	century.setText("একশত: "+cenCount);
            	total.setTypeface(font);
            	total.setText("সর্বমোট: "+totalCount);
            }
        });
		clr.setOnClickListener(new View.OnClickListener() {
			//Vibrator vibe =  (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            @Override
            public void onClick(View v) {
            	 count=0;cenCount=0;totalCount=0;
            	//vibe.vibrate(100);
            	century.setTypeface(font);
            	century.setText("একশত: "+cenCount);
            	total.setTypeface(font);
            	total.setText("সর্বমোট: "+totalCount);
            }
        });
        
		
	}
		
}
