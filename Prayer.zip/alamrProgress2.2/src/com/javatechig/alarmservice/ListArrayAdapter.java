package com.javatechig.alarmservice;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListArrayAdapter extends ArrayAdapter<String> {
	private final Context context;
	private final String[] values;
	Typeface font;
	public ListArrayAdapter(Context context, String[] values) {
		super(context, R.layout.adapter, values);
		//font = Typeface.createFromAsset(context.getAssets(), FONT);
		this.context = context;
		this.values = values;
	}
 
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LayoutInflater inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		 //Typeface font = Typeface.createFromAsset(getActivity().getAssets(),"SolaimanLipi-8-Jan-2011.ttf");
		View rowView = inflater.inflate(R.layout.adapter, parent, false);
		TextView textView = (TextView) rowView.findViewById(R.id.label);
		
		ImageView imageView = (ImageView) rowView.findViewById(R.id.logo);
		textView.setText(values[position]);
 
		// Change icon based on name
		String s = values[position];
 
		System.out.println(s);
 
		if (s.equals("Kalima")) {
			imageView.setImageResource(R.drawable.kalima);
		} else if (s.equals("Namaz")) {
			imageView.setImageResource(R.drawable.namaz);
		} else if (s.equals("Zakat")) {
			imageView.setImageResource(R.drawable.zakat);
		} else if (s.equals("Roja")) {
			imageView.setImageResource(R.drawable.food);
		} else if (s.equals("Daily sunnots")) {
			imageView.setImageResource(R.drawable.sunnah);
		}else if (s.equals("Eid's")) {
			imageView.setImageResource(R.drawable.eid);
		} else if (s.equals("Kabar Ziarat")) {
			imageView.setImageResource(R.drawable.kabar);
		} else if (s.equals("Foroz oF Salaz,Showe,Ozu")) {
			imageView.setImageResource(R.drawable.foraz);
		} else if (s.equals("Hajj")) {
			imageView.setImageResource(R.drawable.hajjj);
		} else if (s.equals("Dua,Zikir,Dress code")) {
			imageView.setImageResource(R.drawable.zakat);
		}else if (s.equals("Halam,Haram Foods")) {
			imageView.setImageResource(R.drawable.food);
		} else if (s.equals("Suras")) {
			imageView.setImageResource(R.drawable.sura);
		} else if (s.equals("Zannat")) {
			imageView.setImageResource(R.drawable.jant);
		} else if (s.equals("Zahannam")) {
			imageView.setImageResource(R.drawable.jahannam);
		}else if (s.equals("Death OF Momin")) {
			imageView.setImageResource(R.drawable.kalima);
		} else if (s.equals("Death OF Kafir")) {
			imageView.setImageResource(R.drawable.death);
		} else if (s.equals("About")) {
			imageView.setImageResource(R.drawable.about);
		} 
		else  {
			imageView.setImageResource(R.drawable.zakat);
		}
		return rowView;
	}
}