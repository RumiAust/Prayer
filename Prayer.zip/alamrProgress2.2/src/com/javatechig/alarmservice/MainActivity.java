package com.javatechig.alarmservice;


import android.app.ActionBar;
import android.app.Dialog;
import android.app.TabActivity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.Toast;

public class MainActivity extends TabActivity {
	TabHost tabHost;
	 private int currentTab = 0;
	 private int lastTab = 0;
	 Typeface font;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		ActionBar acBar= getActionBar();
		//acBar.setBackgroundDrawable(new ColorDrawable(0x0066FF));
		//#FF6600,0066FF
		acBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#FF6600")));
		font = Typeface.createFromAsset(getAssets(),"SolaimanLipi-8-Jan-2011.ttf");
		Resources ressources = getResources(); 
	    tabHost = getTabHost(); 
		//
		try{
		Intent intentEng = new Intent().setClass(this, MyActivity.class);
		TabSpec tabSpecEng = tabHost
			.newTabSpec("Engineering")
			.setIndicator("Hadith", ressources.getDrawable(R.drawable.ic_launcher))
			.setContent(intentEng);
		//tasbi
		Intent intentTasbi = new Intent().setClass(this, Tasbi.class);
		TabSpec tabSpecTasbi = tabHost
			.newTabSpec("Tasbi")
			.setIndicator("Tasbi", ressources.getDrawable(R.drawable.ic_launcher))
			.setContent(intentTasbi);
		//tasbi
		Intent intentListOne = new Intent().setClass(this, ListOne.class);
		TabSpec tabSpecListOne = tabHost
			.newTabSpec("ListOne")
			.setIndicator("prayers", ressources.getDrawable(R.drawable.ic_launcher))
			.setContent(intentListOne);
		//Time
		Intent intentTime = new Intent().setClass(this, ListTwo.class);
		TabSpec tabSpecTime = tabHost
			.newTabSpec("ListOne")
			.setIndicator("Time", ressources.getDrawable(R.drawable.ic_launcher))
			.setContent(intentTime);
		
		//
		tabHost.addTab(tabSpecListOne);
		tabHost.addTab(tabSpecEng);
		tabHost.addTab(tabSpecTime);
		tabHost.addTab(tabSpecTasbi);
		
		tabHost.setCurrentTab(0);
		//tabHost.setBackgroundColor(Color.parseColor("#DCDCDC"));
		getTabWidget().getChildAt(0).setBackgroundColor(Color.parseColor("#FFFAFA"));
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {

	        @Override
	        public void onTabChanged(String tabId) {
	        	 for (int i = 0; i < tabHost.getTabWidget().getChildCount(); i++) {

	        	        if (tabHost.getTabWidget().getChildAt(i).isSelected()) {
	        	           // SessionState.getSelectedIndex().setSelectedPage(i);
	        	            tabHost.getTabWidget()
	        	                    .getChildAt(i)
	        	                    .setBackgroundColor(Color.parseColor("#FFFAFA"));
	        	        } else {

	        	            tabHost.getTabWidget()
	        	                    .getChildAt(i)
	        	                    .setBackgroundColor(Color.parseColor("#D3D3D3"));

	        	        }
	        	    }

	        	}
	        
	    });

		
		
		
		}catch(Exception e){
			Toast.makeText(getApplicationContext(), ""+e, Toast.LENGTH_LONG).show();
		}
		setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.my, menu);
		return true;
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		
		switch (item.getItemId()) {
		case R.id.instrct:

			

			break;

		case R.id.hadithpref:
			
			Intent quizView = new Intent("com.javatechig.alarmservice.SetDistrict");
			startActivity(quizView);
			break;
		case R.id.hlp:

			break;
		case R.id.abt:
			final Dialog d = new Dialog(this);
		  	d.setContentView(R.layout.customdialogbox);
			d.setTitle("About Us ");
			TextView txt=(TextView)d.findViewById(R.id.tv1);
			txt.setText("MD.Golam Muktadir Rumi\nEmail:ruuummee@gmail.com\nAust,Department OF CSE\n\n" +
					"Mashruf Mustavi Arpan\nEmail:mashruf93@gmail.com\nAust,Department OF CSE\n\n" +
					"Tanjim Ul Haque Aditto\nEmail:aditto874@gmail.com\nAust,Department OF CSE");
			 Button b =(Button)d.findViewById(R.id.dialogButtonOK);
			b.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					d.dismiss();
				}
				
			});
			
			d.show();
			break;
		
		}
		return false;
	}
}
